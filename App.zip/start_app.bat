@echo off
title Accountant_sys - ?????????????? ??????????
cd /d "%~dp0"
if not exist Accountant_sys.exe (
    echo [X] Accountant_sys.exe not found in this folder. Run publish_app.ps1 again.
    pause
    exit /b 1
)
echo Starting Accountant_sys on http://localhost:5000 ...
start "" http://localhost:5000
Accountant_sys.exe --urls http://localhost:5000